import { createContext } from 'react';

export const AppContext = createContext({});
export const AuthContext = createContext({});
export const RoutesContext = createContext({});
export const SnackContext = createContext({});
export const BookingContext = createContext({});
